import React, { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import App from './App.jsx'

function MyApp() {
    return (
        <div>
            <a href='https://www.google.com' target='_blank'>New link to go to google</a>
        </div>
    )
}

const AnotherElement = (
    <a href='https://www.google.com' target='_blank'> Go to google</a>
)

const anotherUser = "chai or react";

const reactElement = React.createElement(
    'a',
    { href: 'https://www.google.com', target: '_blank' },
    'Link to google',
    anotherUser
)

createRoot(document.getElementById('root')).render(
    // <App/>
    // <MyApp/> 
    // AnotherElement
    reactElement
)
