import Chai from "./Chai.jsx";

function App() {
  return (
    <>
    <Chai/>
     <h1>Hello World | Simranjit kaur, Roll no -{38}</h1>
    </>
  )
}

export default App

