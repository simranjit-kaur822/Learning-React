function Chai(){
    return(
        <h1>Chai is ready</h1>
    )
}
export default Chai